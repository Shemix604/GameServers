
package com.shimi.gameservers

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
