
import 'package:flutter/material.dart';

void main() {
  runApp(const GameServersApp());
}

class GameServersApp extends StatelessWidget {
  const GameServersApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'גיים סרברס',
      home: const ServerListScreen(),
      locale: const Locale('he'),
      supportedLocales: const [Locale('he')],
    );
  }
}

class ServerListScreen extends StatelessWidget {
  const ServerListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final servers = [
      {'name': 'שרת CS 1', 'ip': '192.168.1.10', 'votes': 120},
      {'name': 'שרת GTA SAMP ישראל', 'ip': '192.168.1.25', 'votes': 89},
      {'name': 'שרת מיינקראפט', 'ip': 'play.mc.co.il', 'votes': 212},
    ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('רשימת שרתים')),
        body: ListView.builder(
          itemCount: servers.length,
          itemBuilder: (context, index) {
            final server = servers[index];
            return ListTile(
              title: Text(server['name']!),
              subtitle: Text(server['ip']!),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.star, color: Colors.amber),
                  Text('${server['votes']}'),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
