// Main Flutter app file
void main() => runApp(GameServersApp());